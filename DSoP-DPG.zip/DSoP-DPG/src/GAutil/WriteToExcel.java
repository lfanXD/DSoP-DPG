/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package GAutil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * To Excel Utils
 * @author Administrator
 *
 */
public class WriteToExcel {
	
	private static List<String> CELL_HEADS;
	
	static{
		CELL_HEADS = new ArrayList();
		CELL_HEADS.add("cost");
	}
	
	
	public static Workbook exportData(List<Double> dataList){
		Workbook workbook = new HSSFWorkbook();//Excel
		
		Sheet sheet = buildDataSheet(workbook);
		int rowNum = 1;
		
		for(Double data : dataList){
			if(data == null)
				continue;
			Row row = sheet.createRow(rowNum++);
			convertDataToRow(data, row);
		}
		
		return workbook;
	}
	
	
	
	private static void convertDataToRow(Double data, Row row) {
		int cellNum = 0;
		Cell cell;
		cell = row.createCell(cellNum++);
		
		cell.setCellValue(null == data ? null : data);
		
	}



	private static Sheet buildDataSheet(Workbook workbook){
		Sheet sheet = workbook.createSheet();
		
		for (int i=0; i<CELL_HEADS.size(); i++) {
			   sheet.setColumnWidth(i, 4000);
		}
		
		CellStyle cellStyle = buildHeadCellStyle(sheet.getWorkbook());
		
		Row head =  sheet.createRow(0);
		  for (int i = 0; i < CELL_HEADS.size(); i++) {
		   Cell cell = head.createCell(i);
		   cell.setCellValue(CELL_HEADS.get(i));
		   cell.setCellStyle(cellStyle);
		  }
		
		return sheet;
	}
	
	
	//set style
	private static CellStyle buildHeadCellStyle(Workbook workbook){
		CellStyle style = workbook.createCellStyle();
		  
		  style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		  
		  style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		  
		  style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		  
		  style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		  
		  style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		  
		  Font font = workbook.createFont();
		  style.setFont(font);
		  return style;
	}

}

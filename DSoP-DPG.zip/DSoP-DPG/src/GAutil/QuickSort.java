/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package GAutil;


public class QuickSort {
	
	private double[] array;
	private SolutionStructure ss;
	private int end;
	
	public QuickSort(double[] a){
		this.array = new double[a.length];
		array = a;
	}
	
	public QuickSort(SolutionStructure s, int end){
		this.ss = s;
		this.end = end;
	}
	
	public void sortAscentDouble(){
		quickSort(0,end-1);
	}
	
	public void sortDescentDouble(){
		quickSort(0,end-1);
		reverse();
		display();
	}
	
	public void sortAscentStructure(){
		quickSortStructure(0,end-1);
	}
	
	private void quickSort(int p, int r){
		if(p < r){
			int q = partition(p,r);
			quickSort(p,q-1);
			quickSort(q+1,r);
		}
	}
	
	private int partition(int p, int r){
		double x = array[r];
		int i = p - 1;
		for(int j = p; j <= r - 1; ++j){
			if(array[j] <= x){
				i += 1;
				double temp = array[j];
				array[j] = array[i];
				array[i] = temp;
			}
		}
		double temp = array[r];
		array[r] = array[i+1];
		array[i+1] = temp;
		return i+1;
	}
	
	private void quickSortStructure(int p, int r){
		if(p < r){
			int q = partitionStructure(p,r);
			quickSortStructure(p,q-1);
			quickSortStructure(q+1,r);
		}
	}
	
	private int partitionStructure(int p, int r){
		
		double x = ss.getFitness()[r];
		int i = p - 1;
		for(int j = p; j <= r - 1; ++j){
			
			if(ss.getFitness()[j] <= x){
				i += 1;
				double tempF = ss.getFitness()[j];
				String tempP = ss.getPop()[j];
				ss.getFitness()[j] = ss.getFitness()[i];
				ss.getPop()[j] = ss.getPop()[i];
				ss.getFitness()[i] = tempF;
				ss.getPop()[i] = tempP;
			}
		}
		double tempF = ss.getFitness()[r];
		String tempP = ss.getPop()[r];
		ss.getFitness()[r] = ss.getFitness()[i+1];
		ss.getPop()[r] = ss.getPop()[i+1];
		ss.getFitness()[i+1] = tempF;
		ss.getPop()[i+1] = tempP;
		return i+1;
	}
	
	private void display(){
		for(int i = 0; i < array.length; ++i){
			System.out.print(array[i] + " ");
		}
		System.out.println("");
	}
	
	private void reverse(){
		double[] temp = new double[array.length];
		for(int i = 0; i < array.length; ++i){
			temp[i] = array[array.length-1-i];
		}
		array = temp;
	}
	
	public double[] getDoubleResult(){
		return array;
	}
	
	public SolutionStructure getStructureResult(){
		return ss;
	}
}

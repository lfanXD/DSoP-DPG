/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package GAutil;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class ReadFile{
	
	
	public String readFile(File file, int number)
	{
		String result = null;
		FileInputStream fs;
		try
		{
			fs = new FileInputStream(file);
			BufferedReader br = new BufferedReader(new InputStreamReader(fs)); 
			String line = null;
			int flag = 0;
			while((line = br.readLine())!=null)
			{
				if (number == flag)
				{
					result = line;
					break;
				}
				flag ++;
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * string2int
	 * @param str
	 * @return
	 */
	public int[] TurnTheStringArray(String str) {
		 String[] strp=str.split(",");
		 int[] ints = new int[strp.length];
		    for(int i=0;i<strp.length;i++){
		        ints[i] = Integer.parseInt(strp[i]);
		        System.out.print(ints[i]);
		    }
		return ints;
	}

	public static void main(String args[]){
		File file = new File("file path");
	    ReadFile r = new ReadFile();
	    String li = r.readFile(file,2);
	    r.TurnTheStringArray(li);
	}
	
}

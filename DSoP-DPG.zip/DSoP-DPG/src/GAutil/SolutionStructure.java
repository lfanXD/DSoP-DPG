/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package GAutil;

public class SolutionStructure {
	private String[] pop;
	private double[] fitness;
	
	public SolutionStructure(String[] p, double[] f){
		pop = p;
		fitness = f;
	}
	
	public String[] getPop(){
		return pop;
	}
	
	public double[] getFitness(){
		return fitness;
	}
}

/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package GAutil;

/**
 * BestSolution
 *
 */
public class BestSolution {
	private int generation;//generation
	private String strategy;//optimal storage strategy
	private double fitness;//optimal service cost
	private long time;//time
	private int ComputeCountForBest;
	private int ComputeCountForAll;
	
	public BestSolution(){
		this.fitness = 999999;
		this.generation = -1;
		this.strategy = "";
		this.time = -1;
		this.ComputeCountForBest = 0;
		this.ComputeCountForAll = 0;
	}
	
	public BestSolution(BestSolution b){
		this.strategy = b.getStrategy();
		this.fitness = b.getFitness();
		this.generation = b.getGeneration();
	}
	
	public int getGeneration(){
		return this.generation;
	}
	
	public String getStrategy(){
		return this.strategy;
	}
	
	public double getFitness(){
		return this.fitness;
	}
	
	public long getTime(){
		return this.time;
	}
	
	public int getComputeCountForBest(){
		return this.ComputeCountForBest;
	}
	
	public int getComputeCountForAll(){
		return this.ComputeCountForAll;
	}
	
	public void setGeneration(int g){
		this.generation = g;
	}
	
	public void setStrategy(String s){
		this.strategy = s;
	}
	
	public void setFitness(double f){
		this.fitness = f;
	}
	
	public void setTime(long t){
		this.time = t;
	}
	
	public void setComputeCountForBest(int c){
		this.ComputeCountForBest = c;
	}
	
	public void setComputeCountForAll(int c){
		this.ComputeCountForAll = c;
	}
	
	public void display(){
		System.out.println("fitness:" + this.fitness);
		System.out.println("strategy��" + this.strategy);
		System.out.println("generation��" + this.generation);
		System.out.println("time��" + this.time+"ms");
		
	}
	
	public boolean equalWith(BestSolution b){
		if( this.strategy.equals(b.getStrategy()) &&
			this.fitness == b.getFitness() &&
			this.generation == b.getGeneration() 
		  ){
			return true;
		}else{
			return false;
		}
	}
	
}


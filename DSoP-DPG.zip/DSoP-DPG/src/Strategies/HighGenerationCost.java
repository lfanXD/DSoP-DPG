/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */


package Strategies;


public class HighGenerationCost {

	
	public String getStrategyByStorageCost(double[] time,int[] frequency,double rate){
        double le1 = time.length * rate ;
        double[] time1 = new double[time.length];
        for(int i=0;i<time.length;i++){
            time1[i]=time[i];
        }
        int le = (int)Math.round(le1);
        int[] r = new int[time.length];
        int temp=0;
        double temp1= 0;

        
        for(int i=0;i<time.length;i++) { r[i]= i;}
        for(int j=0;j<time1.length;j++){
            for(int k=j;k<time1.length;k++){
                if(time1[j]<time1[k]){
                    temp1 = time1[j];
                    time1[j]=time1[k];
                    time1[k]=temp1;

                    temp = r[j];
                    r[j]=r[k];
                    r[k]=temp;
                }
            }
        }
        int [] resu2 = new int [time.length];
        for(int i=0;i<le;i++){
            resu2[r[i]]=1;
        }
        resu2[0]=1;
        
        char[] cresu1 = new char[resu2.length];
        for(int i=0;i<resu2.length;i++) {
        	cresu1[i] = (char) (resu2[i]+'0');
        	
        }
        String s =new String(cresu1);
 
        return s;
        
    }

	
}

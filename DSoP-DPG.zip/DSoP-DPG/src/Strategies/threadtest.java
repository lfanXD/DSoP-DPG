/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package Strategies;

import Workflow.WorkflowStructure;

public class threadtest extends Thread {
	private ReExhaustion re;
	
	public threadtest(ReExhaustion re){
		this.re = re;
		
	}

	@Override
	public void run() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		re.getL(7);
	}
	
}

/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package Strategies;

import java.util.*;

import GAutil.BestSolution;
import Workflow.WorkflowStructure;

/**
 * Enumeration method for DSoP-PCE
 * @author Administrator
 *
 */
public class NoReExhaustion {
	
	private int LengthOfCode;
	private WorkflowStructure workflow;
	private final static char STORED = '1'; 
	private final static int CONNECTED = 1; 
	private String[] coNum;
	private Node[] table;
	private double[] costArr;
	public BestSolution best;
	public Map<Integer, Double> map = new HashMap<Integer, Double>();
	private List<Double> list = new ArrayList();
	
	
	public List<Double> getList(){
		return list;
		
	}
	
	
	class Node{
		private List<Integer> preNode;
		public Node(){
			preNode = new ArrayList<Integer>();
		}
		public List<Integer> getPreNode(){
			return preNode;
		}
	}
	
	public WorkflowStructure getWorkflow()
	{
		return this.workflow;
	}
	
	/**
	 * Construct function
	 */
	public NoReExhaustion(WorkflowStructure w ,int L)
	{
		this.workflow=w;
		this.LengthOfCode=L;
		this.best=new BestSolution();
		this.coNum=new String[(int) Math.pow(2,L-1)];
		this.costArr=new double[(int) Math.pow(2,L-1)];	
		this.table=new Node[L];
		for(int i=0; i<L; i++){
			table[i] = new Node();
			for(int j=0; j<L; j++){
				if(CONNECTED==workflow.getGraph()[j][i]){
					table[i].getPreNode().add(j);
				}
			}
		}
	}
	
	/**
	 * encoding
	 */
	private void encoding(){
		for(int k = 0;k < Math.pow(2,LengthOfCode-1);k++){
			coNum[k] = Integer.toBinaryString(k);		
				if(coNum[k].length()< LengthOfCode){
					int f = LengthOfCode - coNum[k].length();
					for(int t = 0; t < f; ++t){	
						if(t == f-1){
		
							coNum[k] = "1" + coNum[k];
						}else{
							coNum[k] = "0" + coNum[k];
						}	
					}
				}
		}
	}
	
	/**
	 * get cost evaluation function
	 * @param Strategy 
	 * @param Frequency
	 * @return
	 */
	public double getCostOfStrategy(int[] Frequency){
		String strategy = "10000000010010000000111001";
		workflow.setFrequency(Frequency);
		return getTotalCost();
	}
	
	private void totalCost(int size){
		for(int i = 0; i < size; ++i){
			costArr[i] = this.getTotalCost();
		}
	}
	

	private double getTotalCost(){
		String strategy = "10000000010010000000111001";
		double StoreCost = 0;
		double CompCost = 0;
		double cost = 0;
		for(int j = 0; j < LengthOfCode; ++j){
			if(strategy.charAt(j) == '1'){
				StoreCost += workflow.getDataSize()[j]*workflow.getStoringCost();
			}else{
				CompCost += getResult(strategy,j);
				CompCost *= workflow.getFrequency()[j];
			}
			cost += StoreCost;
			cost += CompCost;
			StoreCost = 0;
			CompCost = 0;
		}
		double totalcost=(double)(Math.round(cost*1000))/1000;
	
		System.out.println(totalcost);
		return totalcost;
	}
	
	public double getResult(String Strategy,int pos){
		map = new HashMap<Integer, Double>();
		return calculateCostOfNode(Strategy,pos);
	}
	
	public double calculateCostOfNode(String Strategy,int pos){
		if(map!=null && map.containsKey(pos)){
			return 0;
		}
		double totalCost=0;
		List<Integer> list = table[pos].getPreNode();
		for(int i=0; i<list.size(); i++){
			int pre = list.get(i);
			if(STORED==Strategy.charAt(pre)){
				System.out.print((pre+1)+"->"+(pos+1)+"   ");
			}
			else{
				totalCost +=calculateCostOfNode(Strategy,pre);
			}
		}
		totalCost=totalCost+workflow.getGenerateTime()[pos]*workflow.getComputingCost();
		double cost=(double)(Math.round(totalCost*1000))/1000;
		map.put(pos, cost);
		return cost;		
	}
	

	private double findResult(int size){
		if(best == null){
			System.out.println("!!!");
			best = new BestSolution();
		}
		double min = best.getFitness();
		for(int i = 0; i < size; ++i){
			if(costArr[i] < min){
				best.setFitness(costArr[i]);
				min = best.getFitness();
				System.out.println("minimal cost��" + min);
				list.add(min);
				best.setStrategy(coNum[i]);
			}
		}
		return min;
	}
	
	public BestSolution getBestSolution(){
		return best;
	}
	
	
	public void display(){
		encoding();
		totalCost((int) Math.pow(2,LengthOfCode-1));
		findResult((int) Math.pow(2,LengthOfCode-1));
	}
		
	
	public double displaynodeCostofStrategy(int pos)
	{
		String Strategy = "10000000010010000000111001";
		if(Integer.valueOf(Strategy.charAt(pos) + "")!=1)
		{
			double totalCost=getResult(Strategy,pos)*workflow.getFrequency()[pos];
			double cost=(double)(Math.round(totalCost*1000))/1000;
		    System.out.println("precise generation cost for "+pos+" dataset is:"+cost+"    ");
			return cost;	
		}
		else
		{
			double totalCost=workflow.getDataSize()[pos]*workflow.getStoringCost()*workflow.getTimePeriod();
			double cost=(double)(Math.round(totalCost*1000))/1000;
			System.out.println("The storage cost for "+pos+" dataset is:" +cost+"    ");
			return cost;
		}
	}
	
}
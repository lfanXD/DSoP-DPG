/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package Strategies;

import java.util.*;
import GAutil.BestSolution;
import Workflow.WorkflowStructure;

/**
 * Enumeration method for DSoP-SCE
 * @author Administrator
 *
 */
public class ReExhaustion {

	private int LengthOfCode;
	private WorkflowStructure workflow;
	private final static int CONNECTED = 1; 
	private String[] coNum;
	private Node[] table;
	private double[] costArr;
	public BestSolution best;
	public Map<Integer, Double> map = new HashMap<Integer, Double>();

	
	class Node{
		private List<Integer> preNode;
		public Node(){
			preNode = new ArrayList<Integer>();
		}
		public List<Integer> getPreNode(){
			return preNode;
		}
	}
	
	public WorkflowStructure getWorkflow()
	{
		return this.workflow;
	}
	
	/**
	 * Construct function
	 */
	public ReExhaustion(WorkflowStructure w ,int L)
	{
		this.workflow=w;
		this.LengthOfCode=L;
		this.best=new BestSolution();
		this.coNum=new String[(int) Math.pow(2,LengthOfCode-1)];
		this.costArr=new double[(int) Math.pow(2,LengthOfCode-1)];	
		this.table=new Node[L];
		for(int i=0; i<L; i++){
			table[i] = new Node();
			for(int j=0; j<L; j++){
				if(CONNECTED==workflow.getGraph()[j][i]){
					table[i].getPreNode().add(j);
				}
			}
		}
	}
	
	
	private void encoding(){
		for(int k = 0;k < Math.pow(2,LengthOfCode-1);k++){
			coNum[k] = Integer.toBinaryString(k);		
				if(coNum[k].length()< LengthOfCode){
					int f = LengthOfCode - coNum[k].length();
					for(int t = 0; t < f; ++t){	
						if(t == f-1){
						
							coNum[k] = "1" + coNum[k];
						}else{
							coNum[k] = "0" + coNum[k];
						}	
					}
				}	
		}
	}
	

	
	
	private void totalCost(int size){
		for(int i = 0; i < size; ++i){
			costArr[i] = this.getTotalCost();
		}
	}
	
	
	private double getTotalCost(){
		String strategy = "1000000000000000010001";
		double StoreCost = 0;
		double CompCost = 0;
		double cost = 0;
		for(int j = 0; j < LengthOfCode; ++j){
			if(strategy.charAt(j) == '1')
			{
				StoreCost += workflow.getDataSize()[j]*workflow.getStoringCost()*workflow.getTimePeriod();
			}
			else
			{
				CompCost += recurseComputingCost(strategy,j);
				CompCost *=  workflow.getFrequency()[j];
			}
			cost += StoreCost;
			cost += CompCost;
			StoreCost = 0;
			CompCost = 0;
		}
		double totalcost=(double)(Math.round(cost*1000))/1000;
		return totalcost;
	}	
	private  double recurseComputingCost(String strategy, int pos){
		double totalCost=0;
		List<Integer> list = table[pos].getPreNode();
		for(int i=0; i<list.size(); i++){
			int pre = list.get(i);
			if('1'!=strategy.charAt(pre)){
				totalCost =totalCost+recurseComputingCost(strategy,pre);
			}
		}
		totalCost+=workflow.getGenerateTime()[pos]*workflow.getComputingCost();
		return totalCost;
	}
	

	private double findResult(int size){
		if(best == null){
			System.out.println("!!!");
			best = new BestSolution();
		}
		double min = best.getFitness();
		for(int i = 0; i < size; ++i){
			if(costArr[i] < min){
				best.setFitness(costArr[i]);
				min = best.getFitness();
				best.setStrategy(coNum[i]);
			}
		}
		return min;
	}
	
	
	public BestSolution getBestSolution(){
		return best;
	}
	
	
	public void display(){
		encoding();
		totalCost((int) (Math.pow(2,LengthOfCode-1)));
		findResult((int) (Math.pow(2,LengthOfCode-1)));
		getTotalCost();
	}
	
	
	
	
	public  void getL(int LengthOfCode){
		synchronized (this) {
			
			if(LengthOfCode-1>26){
				System.out.println("over length");
				int a = (int) Math.pow(2, LengthOfCode-1);
				
			}else{
				long startTime = System.currentTimeMillis();
				System.out.println(Thread.currentThread().getName());
				display();
				getBestSolution();
				System.out.println("Fitness: "+best.getFitness());
				System.out.println("Strategy:"+best.getStrategy());
				long endTime = System.currentTimeMillis();
			    System.out.println("run time��" + (endTime - startTime) + "ms");
			}
		}
		
	}	
	
	

	public double getnodeCostofStrategy(int pos)
	{
		String Strategy = "1000000000000000010001";
		if(Integer.valueOf(Strategy.charAt(pos) + "")==0)
		{
			double totalCost=recurseComputingCost(Strategy, pos)*workflow.getFrequency()[pos];
			double cost=(double)(Math.round(totalCost*1000))/1000;
			System.out.println("The precise generation cost for"+pos+"dataset is:"+cost+"    ");
			return cost;			
		}
		else
		{
			double totalCost= workflow.getDataSize()[pos]*workflow.getStoringCost();
			double cost=(double)(Math.round(totalCost*1000))/1000;
			System.out.println("The storage cost for "+pos+" dataset is:" +cost+"    ");
			return cost;	
		}
	}

}
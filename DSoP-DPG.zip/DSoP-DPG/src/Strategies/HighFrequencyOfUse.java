/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package Strategies;


public class HighFrequencyOfUse {
 
	
	public String getStrategyByFrequency(int[] frequency,double rate){
        double le1 = frequency.length * rate ;
        int le = (int)Math.round(le1);
        
        int[] freq1 = new int[frequency.length];
        for(int i=0;i<frequency.length;i++){
            freq1[i]=(int)frequency[i];
        }
        
        int[] r = new int[frequency.length];
        int temp=0;
        int temp1= 0;
        for(int i=0;i<freq1.length;i++) {
        	r[i]= i;
        }
        for(int j=0;j<freq1.length-1;j++){
            for(int k=j+1;k<freq1.length;k++){
                if(freq1[j]<freq1[k]){
                    temp1 = freq1[j];
                    freq1[j]=freq1[k];
                    freq1[k]=temp1;

                    temp = r[j];
                    r[j]=r[k];
                    r[k]=temp;
                }
            }
        }
        int [] resu1 = new int [freq1.length];
        for(int i=0;i<le;i++){
            resu1[r[i]]=1;
        }
        resu1[0]=1;
        char[] cresu1 = new char[resu1.length];
        
        for(int i=0;i<resu1.length;i++) {
        	cresu1[i] = (char) (resu1[i]+'0');
        	
        }
        String str =  new String(cresu1);
        return str;
    }

	


     	
}

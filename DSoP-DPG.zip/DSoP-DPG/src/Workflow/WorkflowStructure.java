/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package Workflow;

import java.math.BigDecimal;
import java.util.List;

/**
 * workflow structure
 * @author Administrator
 *
 */
public class WorkflowStructure {
	
	private int N;//dataset size
	private int[][] A;//construct CTT
	private double[] D;//node size
	private int[] m;//request number
	private double C,P,t;//storage cost, computation cost, service interval
	private double[] G;//data regeneration time
	
	
	public WorkflowStructure(int n){
		N = n;
		A = new int[N][N];
		D = new double[N];
		m = new int[N];
		G = new double[N];
	}
	
	public boolean setGraph(int[][] graph){
		if(A.length == graph.length){
			A = graph;
			return true;
		}else{
			return false;
		}
	}
	
	public boolean setDataSize(double[] DataSize){
		if(D.length == DataSize.length){
			for(int i = 0; i < DataSize.length; ++i){
				BigDecimal b = new BigDecimal(DataSize[i]);
				double temp = b.setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue();
				D[i] = (int) temp;
			}
			return true;
		}else{
			return false;
		}
	}
	
	public boolean setFrequency(int[] M){
		if(m.length == M.length){
			m = M;
			return true;
		}else{
			return false;
		}
	}
	
	public boolean setGenerateTime(double[] gt){
		if(G.length == gt.length){
			for(int i = 0; i < gt.length; ++i){
				BigDecimal b = new BigDecimal(gt[i]);
				double temp = b.setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue();
				G[i] = temp;
			}
			return true;
		}else{
			return false;
		}
	}
	
	public void setStoringCost(double c){
		C = c;
	}
	
	public void setComputingCost(double p){
		P = p;
	}
	
	public void setTimePeriod(double tp){
		t = tp;
	}
	
	public void display(){
		System.out.println("dataset number of workflow ��" + N);

		System.out.println("dataset size��");
		displayArray(D);
		
		
		System.out.println("dataset request number:");
		displayArray2(m);
		
		System.out.println("dataset producing time:");
		displayArray(G);
		System.out.println("--------------------------------------");
		
		System.out.println("time��"+ t);
		System.out.println("storage cost��" + C);
		System.out.println("computation cost��" + P);
		System.out.println("--------------------------------------");
		
	}
	
	public int getSize(){
		return N;
	}
	
	public int[][] getGraph(){
		return A;
	}
	
	public double[] getDataSize(){
		return D;
	}
	
	public int[] getFrequency(){
		return m;
	}
	
	public double[] getGenerateTime(){
		return G;
	}
	
	public double getStoringCost(){
		return C;
	}
	
	public double getComputingCost(){
		return P;
	}
	
	public double getTimePeriod(){
		return t;
	}
	
	public void generateFrequency(double lamda){
		int[] m = generatePoissonDistribution(N,lamda);
		this.setFrequency(m);
	}
	
	
	private int[] generatePoissonDistribution(int n,double lamda){
		int[] dis = new int[n];
		PoissonDataGenerator pg = new PoissonDataGenerator(lamda);
		dis[0] = 0;		
		for(int i = 1; i < n; ++i){
			dis[i] = pg.getSingleData();
		}
		return dis;
	}
	
	private void displayMatrix(int[][] Martix){
		for(int i = 0 ; i < N; ++i){
			for(int j = 0; j < N; ++j){
				System.out.print(Martix[i][j] + " ");
			}
			System.out.println("");
		}
	}
	
	private void displayArray(double[] m2){
		for(int i = 0; i < N; ++i){
			System.out.print(m2[i] + " ");
		}
		System.out.println("");
	}
	private void displayArray2(int[] m2){
		for(int i = 0; i < N; ++i){
			System.out.print(m2[i] + " ");
		}
		System.out.println("");
	}

	
}

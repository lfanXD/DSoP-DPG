/**
 * JAVA Codes for DSoP
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package Workflow;


public class PoissonDataGenerator {
	
	private double lamda;
	
	public PoissonDataGenerator(double lamda){
		this.lamda = lamda;
	}
	
	public int getSingleData(){
		int x = -1;
		double u;
		double log1,log2;
		log1 = 0;
		log2 = -1*lamda;
		do{
			u = Math.random();
			log1 += Math.log(u);
			++x;
		}while(log1 >= log2);
		return x;
	}
	
	public int[] newfreq(int m){
		int[] nfreq = new int[m];
		for(int i=0;i<m;i++) {
			nfreq[i]=getSingleData();
		}
		return nfreq;
	}
	
}
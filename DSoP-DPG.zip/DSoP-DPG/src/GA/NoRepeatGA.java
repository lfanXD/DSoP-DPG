
/**
 * GA for DSoP-PCE
 * Copyright (c) 2021 Lei FAN. All rights reserved.
 * @author Lei FAN (LFAN#Xidian.Edu.CN, "#" should replaced by "@")
 */

package GA;

import java.text.DecimalFormat;
import java.util.*;

import GAutil.*;
import Workflow.WorkflowStructure;


public class NoRepeatGA {
	private int LengthOfCode;
	private WorkflowStructure workflow;
	private int POPSIZE;
	private int MAXPOPSIZE;
	private final static char STORED = '1'; //store or not
	private final static int CONNECTED = 1; //Link Status
	private String[] pop;
	private Node[] table;
	private double[] fitness;
	private double PC = 0.98; //crossover probability
	private double PM = 0.02; //mutation probability
	public Map<Integer, Double> map = new HashMap<Integer, Double>(); 
	public static Random random = new Random();
	public static BestSolution best;	
	private final static double INF = 9999999; 	
	private int ComputeCount = 0;
	private List<Double> list = new ArrayList<Double>();
	
	
	public List<Double> getList(){
		return list;
		
	}
	
	/**
	 * Node class: set of Precursor nodes
	 * @author Administrator
	 *
	 */
	class Node{
		private List<Integer> preNode; //Node List
		public Node(){
			preNode = new ArrayList<Integer>();
		}
		public List<Integer> getPreNode(){
			return preNode;
		}
	}
	/**
	 * get workflow
	 * @return
	 */
	public WorkflowStructure getWorkflow()
	{
		return this.workflow;
	}
	/**
	 * get optima
	 * @return
	 */
	public BestSolution getBestSolution(){
		return best;
	}
	/**
	 * Construct function1
	 * @param w
	 * @param L
	 */
	public NoRepeatGA(WorkflowStructure w,int L)
	{
		this.workflow=w;
		this.POPSIZE=100;
		this.MAXPOPSIZE=this.POPSIZE*2;
		this.PC=0.98;
		this.PM=0.02;
		this.LengthOfCode=L;
		this.best=new BestSolution();
		this.pop=new String[MAXPOPSIZE];
		this.fitness=new double[MAXPOPSIZE];
		this.table=new Node[L];
		for(int i=0; i<L; i++){
			table[i] = new Node();
			for(int j=0; j<L; j++){
				if(CONNECTED==workflow.getGraph()[j][i]){
					table[i].getPreNode().add(j);
				}
			}
		}
	}
	/**
	 * Construct function2
	 * @param w
	 */
	public NoRepeatGA(WorkflowStructure w){
		this.workflow=w;
		this.POPSIZE =100;
		this.MAXPOPSIZE = this.POPSIZE * 2;
		this.pop=new String[MAXPOPSIZE];
		this.fitness=new double[MAXPOPSIZE];	
		this.PC = 0.98; 
		this.PM = 0.02; 
		this.LengthOfCode = workflow.getSize();
		this.best = new BestSolution();
		this.table=new Node[LengthOfCode];
		for(int i=0; i<LengthOfCode; i++){
			table[i] = new Node();
			for(int j=0; j<LengthOfCode; j++){
				if(CONNECTED==workflow.getGraph()[j][i]){
					table[i].getPreNode().add(j);
				}	
			}
		}
	}
	/**
	 * Construct function3
	 * @param w
	 * @param L
	 * @param popsize
	 * @param CrossRate
	 * @param MutaRate
	 */
	public NoRepeatGA(WorkflowStructure w, int L,int popsize, double CrossRate, double MutaRate){
		this.workflow=w;
		this.POPSIZE = popsize;
		this.MAXPOPSIZE = this.POPSIZE * 2;
		this.pop=new String[MAXPOPSIZE];
		this.fitness=new double[MAXPOPSIZE];	
		this.PC = CrossRate; 
		this.PM = MutaRate; 
		this.LengthOfCode = L;
		NoRepeatGA.best = new BestSolution();
		this.table=new Node[LengthOfCode];
		for(int i=0; i<LengthOfCode; i++){
			table[i] = new Node();
			for(int j=0; j<LengthOfCode; j++){
				if(CONNECTED==workflow.getGraph()[j][i]){
					table[i].getPreNode().add(j);
				}
			}
		}
	}
	
	/**
	 * Construct function with elites
	 */
	public NoRepeatGA(WorkflowStructure w, int L,int popsize, double CrossRate, double MutaRate,int e){
		this.workflow=w;
		this.POPSIZE = popsize;
		this.MAXPOPSIZE = this.POPSIZE * 2;
		this.pop=new String[MAXPOPSIZE];
		this.fitness=new double[MAXPOPSIZE];	
		this.PC = CrossRate; 
		this.PM = MutaRate; 
		this.LengthOfCode = L;
		NoRepeatGA.best = new BestSolution();
		this.table=new Node[LengthOfCode];
		for(int i=0; i<LengthOfCode; i++){
			table[i] = new Node();
			for(int j=0; j<LengthOfCode; j++){
				if(CONNECTED==workflow.getGraph()[j][i]){
					table[i].getPreNode().add(j);
				}
			}
		}
	}
	
	
	
	/**
	 * Encoding
	 */
	private void encoding(){
		int HIGHBOUND = (int) (Math.pow(2, LengthOfCode) - 1);
		for(int i = 0; i < POPSIZE; ++i){
			double d1 = random.nextInt(HIGHBOUND);
			pop[i] = Integer.toBinaryString((int)d1);
		}
		
		//Complete individual codes
		for(int i = 0; i < POPSIZE; ++i){
			if(pop[i].length() < LengthOfCode){
				int k = LengthOfCode - pop[i].length();
				for(int j = 0; j < k; ++j){
					if(j == k-1){
						pop[i] = "1" + pop[i];
					}else{
						pop[i] = "0" + pop[i];
					}
				}
			}
		}
	}
	
	
	
	/**
	 * get strategy cost evaluating function
	 * @param Strategy
	 * @param frequency
	 * @return
	 */
	public double getCostOfStrategy(String Strategy,int[] frequency){
		workflow.setFrequency(frequency);
		return getFitnessOf(Strategy);
	}
	
	/**
	 * fitness
	 * Input: population
	 * Output: individual fitness
	 * @param size
	 */
	private void fitness(int size){
		++ComputeCount;
		for(int i = 0; i < size; ++i){
			fitness[i] = this.getFitnessOf(pop[i]);
		}
		DecimalFormat df = new DecimalFormat("#.00");
		double minss = fitness[0];
		double maxdd = fitness[0];
		double vagt = 0 ;
		double sum = 0;
		for(int i = 0; i < size; ++i){
			if(fitness[i] < minss){
				minss = fitness[i];
			}		
			if(fitness[i] > maxdd){
				maxdd = fitness[i];
			}	
			sum += fitness[i];
		}	
	}
	/**
	 * Evaluate Fitness
	 * Input: storage strategy
	 * Output: strategy service cost
	 * @param strategy
	 * @return
	 */
	private double getFitnessOf(String strategy){
		//String strategy = "11000001000000101010001000         ";
		double StoreCost = 0;
		double CompCost = 0;
		double cost = 0;
		for(int j = 0; j < LengthOfCode; ++j){
			if(strategy.charAt(j) == '1'){
				StoreCost += workflow.getDataSize()[j]*workflow.getStoringCost()*workflow.getTimePeriod();
			}else{
				CompCost += getResult(strategy,j);
				CompCost *= workflow.getFrequency()[j];
			}
			cost += StoreCost;
			cost += CompCost;
			StoreCost = 0;
			CompCost = 0;
		}
		double totalcost=(double)(Math.round(cost*1000))/1000;
		return totalcost;
	}
	
	public double getResult(String Strategy,int pos){
		map = new HashMap<Integer, Double>();
		return calculateCostOfNode(Strategy,pos);
	}
	
	public double calculateCostOfNode(String Strategy,int pos){
		//check if Precursor node has been calculated
		 if(map!=null && map.containsKey(pos)){
				return 0;
		    }
		   double totalCost=0;
			List<Integer> list = table[pos].getPreNode();
			for(int i=0; i<list.size(); i++){
				 int pre = list.get(i);
				if(STORED==Strategy.charAt(pre)){
					System.out.print((pre+1)+"->"+(pos+1)+"   ");
				}
				else{
					totalCost +=calculateCostOfNode(Strategy,pre);
				}
				
			}
			totalCost=totalCost+workflow.getGenerateTime()[pos]*workflow.getComputingCost();
			double cost=(double)(Math.round(totalCost*1000))/1000;
			map.put(pos, cost);
			return cost;	
	}
	
	
	/**
	 * Roulette method
	 * Input: individual fitness
	 * Output: next population
	 */
	private void roulettewheel(){
		double[] p = new double[POPSIZE];
		double[] q = new double[POPSIZE];
		
		double sum = 0;
		
		for(int i = 0; i < POPSIZE; ++i){
			sum = fitness[i] + sum;
		}
		
		for(int i = 0; i < POPSIZE; ++i){
			p[i] = fitness[i]/sum;
		}
		
	
		SolutionStructure ss = new SolutionStructure(pop,fitness);
		QuickSort qsStructure = new QuickSort(ss,POPSIZE);
		qsStructure.sortAscentStructure();
		pop = qsStructure.getStructureResult().getPop();
		fitness = qsStructure.getStructureResult().getFitness();
		QuickSort qsDouble = new QuickSort(p);
		qsDouble.sortDescentDouble();
		p = qsDouble.getDoubleResult();
		
		for(int i = 0; i < POPSIZE; ++i){
			if(fitness[i] == 0){
				q[i] = 0;
			}else{
				for(int j = 0; j < i+1 ; ++j){
					q[i] += p[j];
				}
			}
		}
	
		double[] tempFitness = new double[POPSIZE];
		String[] tempPop = new String[POPSIZE];
		double[] ran = new double[POPSIZE];
		for(int i = 0; i < ran.length; ++i){
			ran[i] = random.nextDouble();
		}
		for(int i = 0; i < ran.length; ++i){
			int k = 0;
			for(int j = 0; j < q.length; ++j){
				if(ran[i] < q[j]){
					k = j;
					break;
				}else{
					continue;
				}
			}
			tempPop[i] = pop[k];
			tempFitness[i] = fitness[k];
		}
		
		for(int i = 0; i < POPSIZE; ++i){
			pop[i] = tempPop[i];
			fitness[i] = tempFitness[i];
		}
	}
	
	
	private double findResult(int size,int generation){
		
		if(best == null){
			System.out.println("!!!");
			best = new BestSolution();
		}
		double min = best.getFitness();
		for(int i = 0; i < size; ++i){
			if(fitness[i] < min){
				best.setFitness(fitness[i]);
				min = best.getFitness();
				best.setStrategy(pop[i]);
				best.setGeneration(generation + 1);
			}
		}
		
		System.out.println(best.getFitness());
		list.add(best.getFitness());
		return min;
		
	}
	
	
	
	
	/**
	  * Producing
	  * Input: population
	  * Output: individuals for crossover or mutation
	  */
	private void breed(){
		int count = this.POPSIZE;
		while(count < this.MAXPOPSIZE){
			crossOver(count);//crossover 
			count ++;
		}

	}
	
	/**
	  * selection
	  * Input: population with offspring
	  * Output: population with selected individuals
	  */
	private void select(){
		for(int i = 0; i < POPSIZE; ++i){
			double f = fitness[i];
			if(f != INF){
				for(int j = i + 1; j < POPSIZE; ++j){
					if(pop[i].equals(pop[j])){
						fitness[j] = INF;
					}
				}    
			}
		}
		SolutionStructure ss = new SolutionStructure(pop,fitness);
		QuickSort qsStructure = new QuickSort(ss,MAXPOPSIZE);
		qsStructure.sortAscentStructure();
		pop = qsStructure.getStructureResult().getPop();
		fitness = qsStructure.getStructureResult().getFitness();
		for(int i = 0; i < POPSIZE; ++i){
			if(fitness[i] == INF){
				fitness[i] = this.getFitnessOf(pop[i]);
			}
		}
	}
	
	/** 
	 * crossover
	 * Input: encoded individuals
	 * Output: offspring
	 */	
	private void crossOver(int count){
		for(int i = 0; i < count/2; ++i){
			double d = random.nextDouble();
			if(d < PC){
				int k1 = random.nextInt(count);
				int k2 = random.nextInt(count);
				while(k1 == k2){
					k1 = (int)random.nextInt(count); 
					k2 = (int)random.nextInt(count);
				}
				
				int position = random.nextInt(LengthOfCode);
				
				String s11 = null,s12 = null,s21 = null,s22 = null;		
				s11 = pop[k1].substring(0,position);
				s12 = pop[k1].substring(position,LengthOfCode);
				s21 = pop[k2].substring(0, position);
				s22 = pop[k2].substring(position, LengthOfCode);
				
				if(count < MAXPOPSIZE){	
					pop[count] = s11 + s22;	
					++count;
				}
				if(count < MAXPOPSIZE){	
					pop[count] = s21 + s12;
				}
			}
		}
	}
	
	/** 
	 *Mutation method
	 * Input: NULL
	 * OutPut: mutation offspring
	 */ 
	private void mutation(){
		for(int i = 0; i < POPSIZE; ++i){
			for(int j = 1; j < LengthOfCode; ++j){
				double k = random.nextDouble();
				if(k < PM){
					mutation(i,j);
				}
			}
		}
	}
	
	 /**
	  * Mutation method
	  * OutPut: individual for mutation
	  */
	private void mutation(int i, int j){
		String s = pop[i];
		StringBuffer sb = new StringBuffer(s);
		if(sb.charAt(j) == '0'){
			sb.setCharAt(j, '1');
		}else{
			sb.setCharAt(j, '0');
		}
		pop[i] = sb.toString();
	}

	
	private void evolution(int generation){
		 roulettewheel();//rouletting selection
		 breed();
	     fitness(MAXPOPSIZE);//fitness evaluation
	     findResult(MAXPOPSIZE,generation);
		 select();
		 crossOver(POPSIZE);
		 mutation();
	}
	 
	/**
	 * encoding
	 * @param n
	 */
	public void start(int n){		
		int CountOfUnchange = 0;
		int TempComputeCount = 0;
		int i = 0;
		long StartTime = System.currentTimeMillis();
		long EndTime = 0;
		while(true){
			if(i == 0){
				encoding();
			}else{
				BestSolution tempSolution = new BestSolution(best);
				evolution(i);
				
				if(tempSolution.equalWith(best)){
					++CountOfUnchange;
				}else{
					EndTime = System.currentTimeMillis();
					TempComputeCount = ComputeCount;
				}
				if(CountOfUnchange == 500){
					break;
				}
			}
			++i;
		}
		System.out.println("CountOfUnchange:"+CountOfUnchange);
		best.setTime(EndTime-StartTime);
		best.setComputeCountForBest(TempComputeCount);
		best.setComputeCountForAll(ComputeCount);
	}
	
	/**
	 * cost evaluation
	 * @param Strategy
	 * @param pos
	 * @return
	 */
	public double displaynodeCostofStrategy(String Strategy,int pos)
	{
		if(Integer.valueOf(Strategy.charAt(pos) + "")!=1)
		{
			double totalCost=getResult(Strategy,pos)*workflow.getFrequency()[pos];
			double cost=(double)(Math.round(totalCost*1000))/1000;
		    System.out.println("The precise generation cost for"+pos+"dataset is:"+cost+"  ");
			return cost;			
		}
		else
		{
			double totalCost=workflow.getDataSize()[pos]*workflow.getStoringCost()*workflow.getTimePeriod();
			double cost=(double)(Math.round(totalCost*1000))/1000;
			System.out.println("The storage cost for "+pos+" dataset is:" +cost+"  ");
			return cost;
		}
	}

	
}


